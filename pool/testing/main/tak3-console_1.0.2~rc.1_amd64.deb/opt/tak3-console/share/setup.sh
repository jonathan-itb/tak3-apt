#!/bin/bash
#
# tak3 console installer.
#
# Two ways in, one script:
#   - copied to a host and run:   sudo bash install-console.sh [tak3-console-<version>.jar]
#   - from the package:           sudo tak3-console-setup
#     (apt install tak3-console puts the program in place; this asks the questions)
#
# On a host in a tailnet the console is published INSIDE the tailnet only: the
# service binds to this host's Tailscale address (never 0.0.0.0) and
# `tailscale serve` fronts it with HTTPS. Without a tailnet it listens where
# you say — 127.0.0.1 is the default and the right answer — people sign in with
# passwords and two-step codes, and it answers on an HTTPS port of its own with
# the domain's certificate, which it then needs: passwords are taken over HTTPS
# or a tailnet only, never over plain http or through an SSH tunnel. The owner's
# username and password are chosen here, over SSH, before it first starts.
#
# On a first run it asks the questions that make up application-local.yml and
# writes the file. Every question has a default and every one may be left
# blank: what is skipped is written as a commented line with an explanation,
# so the config is always a complete, documented example of itself and can be
# finished later with an editor and a restart. The fleet itself may be left
# empty — the console starts, and the page says what to add.
#
# Usage:
#   sudo bash install-console.sh [/path/to/tak3-console-<version>.jar]
#   sudo bash install-console.sh --reset-owner [username]   (or: sudo tak3-console-setup --reset-owner)
#       an owner who cannot get in: new password, two-step set up again, everyone signed out
#
# Knobs (environment):
#   PORT=8095                 listen port when 8090 is taken
#   IMPORT=/path/to/yml       registry to import servers from (an arbiter's yaml, or a server list)
#   REVERSE_PROXY=yes         no tailnet, and a reverse proxy on this machine serves the
#                             console over HTTPS (sending X-Forwarded-For and
#                             X-Forwarded-Proto): no HTTPS port of its own is asked for
#
# Safe to re-run: an existing application-local.yml is kept, never overwritten.
# To swap only the jar, use update-console.sh.

set -euo pipefail

# A certificate for the public address is its own small job, not a re-run of setup.
if [ "${1:-}" = --certificate ]; then
    shift
    if [ -n "${TAK3_PACKAGED:-}" ]; then
        TAK3_FOR=console exec /usr/libexec/tak3-console/certificate "$@"
    fi
    TAK3_FOR=console exec bash "$(dirname "$0")/certificate.sh" "$@"
fi

SERVICE=tak3-console.service
SERVICE_USER=tak3-console
INSTALL_DIR=/var/lib/tak3-console
LINK="$INSTALL_DIR/tak3-console.jar"
CONFIG="$INSTALL_DIR/application-local.yml"
UNIT=/etc/systemd/system/$SERVICE
PACKAGED=${TAK3_PACKAGED:-}
DEFAULTS=/etc/default/tak3-console
if [ -n "$PACKAGED" ]; then
    # The package owns the program, the runtime and the unit; this writes only
    # the configuration, which the package never touches.
    CONFIG=/etc/tak3-console/application-local.yml
    JAR=/opt/tak3-console/lib/tak3-console.jar
    ME=tak3-console-setup
else
    ME="bash $0"
fi
# Where it listened before, so a re-run keeps it: the package's defaults file,
# or the ExecStart line of the unit a script install wrote.
PREV_ARGS=""
[ -f "$DEFAULTS" ] && PREV_ARGS=$(grep -m1 '^TAK3_CONSOLE_ARGS=' "$DEFAULTS" | cut -d= -f2- | tr -d '"' || true)
[ -z "$PREV_ARGS" ] && [ -f "$UNIT" ] && PREV_ARGS=$(grep -m1 '^ExecStart=' "$UNIT" || true)
prev_arg() { printf '%s\n' "$PREV_ARGS" | tr ' ' '\n' | grep -m1 -- "^--$1=" | cut -d= -f2- || true; }
PORT=${PORT:-$(prev_arg server.port)}
PORT=${PORT:-8090}

# Progress: every heading says which step it is and what the step is for, so
# an operator watching an install knows how far along it is and whether what
# it is doing now is something they need to care about.
STEP=0
STEPS=9
say()  {
    STEP=$((STEP+1))
    printf '\n\033[1m[%d/%d] %s\033[0m\n' "$STEP" "$STEPS" "$1"
    [ $# -gt 1 ] && printf '      \033[2m%s\033[0m\n' "$2"
    return 0
}
# A heading inside a step, which must not consume a number.
sub()  { printf '\n\033[1m      %s\033[0m\n' "$1"; }
ok()   { printf '   \033[32mok\033[0m  %s\n' "$1"; }
warn() { printf '   \033[33m!!\033[0m  %s\n' "$1"; }
die()  { printf '\n\033[31mFAILED: %s\033[0m\n' "$1" >&2; exit 1; }
hint() { printf '       \033[2m%s\033[0m\n' "$1"; }
# In a folder the service user owns, root does nothing by name: a link the
# service left there, for a file or for a whole folder, would lead root's
# write, copy or chmod wherever it pointed. The service user does it instead,
# and reaches only what it could reach anyway.
as_service() { runuser -u "$SERVICE_USER" -- "$@"; }
# Root writing straight into the service's top folder, whose parent is root's:
# install(1) replaces whatever is at the path, a link included, instead of
# following it, and gives the new file its owner and mode.
place() {  # place SRC DEST OWNER MODE
    [ ! -L "$2" ] || die "$2 is a symbolic link — refusing to write through it"
    install -o "$3" -g "$3" -m "$4" -- "$1" "$2"
}
# The configuration lives in /etc/tak3-console, root's, for the package, and in
# the service's own folder for the script install, where the service user
# reads and writes it (see as_service).
in_config_dir() { if [ -n "$PACKAGED" ]; then "$@"; else as_service "$@"; fi; }
# Replaces the configuration with what comes on stdin, in one rename.
write_config() {
    in_config_dir sh -c 'umask 077; cat > "$1.new" && mv -f -- "$1.new" "$1"' sh "$CONFIG" \
        || die "could not write $CONFIG${PACKAGED:- as $SERVICE_USER}"
}
# A build the person running this put down: in their home, root's, this
# directory or this install's own folder, owned by them, root or the service,
# and writable by no one else. A jar left in /tmp or another user's home could
# be anyone's, and it would be installed and run.
find_jar() {  # find_jar PATTERN [-newer FILE]
    local me=${SUDO_USER:-root} home pattern=$1
    shift
    home=$(getent passwd "$me" | cut -d: -f6 || true)
    find ${home:+"$home"} /root "$PWD" "$INSTALL_DIR" -maxdepth 3 -type f -name "$pattern" "$@" \
        \( -uid 0 -o -uid "$(id -u "$me" 2>/dev/null || echo 0)" -o -uid "$(id -u "$SERVICE_USER" 2>/dev/null || echo 0)" \) \
        ! -perm -002 -print -quit 2>/dev/null || true
}

# ---- asking ----------------------------------------------------------------
# These are inline rather than in a shared file on purpose: each installer is
# copied to a server on its own, and a second file to copy is a step that gets
# forgotten.
#
# Every question accepts a blank answer. What is skipped is remembered here and
# printed at the end, so nobody has to guess which lines of the yaml are still
# placeholders.
SKIPPED=""
skipped() { SKIPPED="$SKIPPED
   - $1"; }

# ask VAR "question" ["default"] ["hint"] — Enter takes the default.
ask() {
    local __var=$1 __q=$2 __def=${3:-} __hint=${4:-} __ans=""
    [ -n "$__hint" ] && hint "$__hint"
    read -r -p "   $__q${__def:+ [$__def]}: " __ans </dev/tty || __ans=""
    printf -v "$__var" '%s' "${__ans:-$__def}"
}

# ask_opt VAR "question" ["hint"] ["what to call it in the summary"]
# Blank is a real answer: the yaml gets a commented placeholder instead.
ask_opt() {
    local __var=$1 __q=$2 __hint=${3:-} __label=${4:-$2} __ans=""
    [ -n "$__hint" ] && hint "$__hint"
    read -r -p "   $__q (blank = skip): " __ans </dev/tty || __ans=""
    [ -n "$__ans" ] || skipped "$__label"
    printf -v "$__var" '%s' "$__ans"
}

# choose VAR "question" "one two three" "default" — re-asks rather than dying,
# because losing ten answered questions to one typo is not acceptable.
choose() {
    local __var=$1 __q=$2 __opts=$3 __def=$4 __ans="" __o
    while :; do
        read -r -p "   $__q [$__def]: " __ans </dev/tty || __ans=""
        __ans=${__ans:-$__def}
        for __o in $__opts; do
            [ "$__ans" = "$__o" ] && { printf -v "$__var" '%s' "$__ans"; return 0; }
        done
        warn "answer one of: $__opts"
    done
}

# yesno VAR "question" y|n
yesno() {
    local __var=$1 __q=$2 __def=$3 __ans=""
    read -r -p "   $__q $([ "$__def" = y ] && echo '(Y/n)' || echo '(y/N)'): " __ans </dev/tty || __ans=""
    __ans=${__ans:-$__def}
    case "$__ans" in [Yy]*) printf -v "$__var" 'y';; *) printf -v "$__var" 'n';; esac
}

# Sign-in through the tailnet needs a tailnet; without one it is passwords.
pick_signin() {
    if [ -n "$TS_IP" ]; then
        echo "     tailnet   - no passwords: tailscale serve names each person and the"
        echo "                 console trusts that. Everyone on the tailnet may look;"
        echo "                 roles for more live in the config file."
        echo "     both      - the tailnet as above, and accounts with passwords (and"
        echo "                 two-step codes) for people outside it, e.g. through a domain."
        echo "     password  - the console keeps accounts of its own; you choose the"
        echo "                 owner's username and password in a moment."
        choose SIGNIN "sign-in" "tailnet both password" "tailnet"
    else
        SIGNIN=password
        ok "password sign-in — there is no tailnet on this host to sign people in with"
        hint "the console keeps accounts of its own: you choose the owner's username and"
        hint "password in a moment, and two-step sign-in is required of everyone."
    fi
}

# ---- the console's own setup commands --------------------------------------
# The owner is made and reset, and the HTTPS address set, by the jar itself
# (java -jar tak3-console.jar setup ...), with the same hashing and rules as
# the web page. It runs as the service user, so its files come out as the
# service writes them; detached from this terminal (setsid), with stdin the
# caller's pipe or /dev/null and stdout captured, so no descriptor of root's
# terminal reaches a process the service user runs; and the password arrives
# on a pipe — never in an argument or the environment, where other users of
# the machine could read it.
if [ -n "$PACKAGED" ]; then JAVA_BIN=/opt/tak3-console/jre/bin/java; JAR_RUN=$JAR
else JAVA_BIN=$(command -v java || echo /usr/bin/java); JAR_RUN=$LINK; fi
PUBLIC_FILE=$INSTALL_DIR/public-address.json
SETUP_ERR=$(mktemp)
run_setup() {
    ( cd "$INSTALL_DIR" && timeout 120 setsid -w runuser -u "$SERVICE_USER" -- \
        "$JAVA_BIN" -jar "$JAR_RUN" setup "$@" 2>"$SETUP_ERR" )
}
stop_for_files() {
    # The running service would write its own copy over ours.
    if systemctl is-active --quiet "$SERVICE"; then systemctl stop "$SERVICE"; ok "stopped the console while its files change"; fi
}
# The accounts file the console uses: the config's, else beside the other state.
accounts_file() {
    local f
    f=$(sed -n 's/^[[:space:]]*accounts-file:[[:space:]]*//p' "$CONFIG" 2>/dev/null | head -1 | tr -d "\"' ")
    case "$f" in
        "") echo "$INSTALL_DIR/accounts.json" ;;
        /*) echo "$f" ;;
        *)  echo "$INSTALL_DIR/${f#./}" ;;
    esac
}
# Who signs in with a password: always without a tailnet; beside one only when
# the password page is open and the tailnet names no owner who can make accounts.
signin_mode() {
    TAILNET_SIGNIN=""; TAILNET_OWNER=""; BOTH=""; NEED_OWNER=""
    if awk '/^[[:space:]]+tailscale:/{t=1;next} t&&/^[[:space:]]+enabled:[[:space:]]*true/{print "yes";exit} /^[^[:space:]]/{t=0}' "$CONFIG" | grep -q yes; then
        TAILNET_SIGNIN=yes
    fi
    if grep -qE '^[[:space:]]+role:[[:space:]]*owner' "$CONFIG"; then TAILNET_OWNER=yes; fi
    if grep -qE '^[[:space:]]+passwords:[[:space:]]*true' "$CONFIG"; then BOTH=yes; fi
    if [ -z "$TAILNET_SIGNIN" ] || { [ -n "$BOTH" ] && [ -z "$TAILNET_OWNER" ]; }; then NEED_OWNER=yes; fi
}
# The HTTPS address as the console saved it (pretty JSON): read without jq,
# which may be missing, and checked before root hands it to curl, getent and ufw.
public_address() {
    KEPT_ON=""; KEPT_HOST=""; KEPT_PORT=""
    [ -f "$PUBLIC_FILE" ] || return 0
    if grep -qE '"enabled"[[:space:]]*:[[:space:]]*true' "$PUBLIC_FILE"; then KEPT_ON=yes; fi
    KEPT_HOST=$(sed -n 's/.*"host"[[:space:]]*:[[:space:]]*"\([a-z0-9.-]*\)".*/\1/p' "$PUBLIC_FILE" | head -1)
    KEPT_PORT=$(sed -n 's/.*"port"[[:space:]]*:[[:space:]]*\([0-9][0-9]*\).*/\1/p' "$PUBLIC_FILE" | head -1)
}
# A new password for the console's web page: typed twice without echo, or made up.
read_new_password() {
    local again=""
    OWNER_PW=""; GENERATED=""
    while :; do
        IFS= read -rs -p "   password (Enter = make up a strong one): " OWNER_PW </dev/tty || OWNER_PW=""; echo
        if [ -z "$OWNER_PW" ]; then
            OWNER_PW=$(openssl rand -base64 18 | tr -d '\n'); GENERATED=yes; return 0
        fi
        IFS= read -rs -p "   the same again: " again </dev/tty || again=""; echo
        [ "$OWNER_PW" = "$again" ] && return 0
        warn "the two differ — once more"
    done
}
# A made-up password is shown once, and only here.
show_generated() {
    [ -n "$GENERATED" ] || return 0
    echo
    echo "      password for $1 (shown once — into your password manager now):"
    echo
    echo "        $OWNER_PW"
    echo
}

# --reset-owner: an owner who cannot get in — a forgotten password, a lost
# phone and its recovery codes, or an account someone else took over — made
# whole again by whoever has root on this machine.
# Where people sign in: the console's own HTTPS address, else its tailnet name
# (tailscale serve). Blank while it has neither — and then nobody can.
signin_url() {
    public_address
    if [ -n "$KEPT_ON" ] && [ -n "$KEPT_HOST" ] && [ -n "$KEPT_PORT" ]; then
        printf 'https://%s:%s' "$KEPT_HOST" "$KEPT_PORT"
        return
    fi
    if command -v tailscale >/dev/null 2>&1; then
        local name
        name=$(tailscale status --json 2>/dev/null | jq -r '.Self.DNSName // ""' 2>/dev/null | sed 's/\.$//' || true)
        [ -z "$name" ] || printf 'https://%s' "$name"
    fi
}

reset_owner() {
    local who=${1:-} out="" rc=0 why="" others="" dis="" https="" name="" link=""
    local extra=(--link)
    [ -f "$CONFIG" ] || die "no console is configured here ($CONFIG) — install it first: sudo $ME"
    { [ -f "$JAR_RUN" ] && [ -x "$JAVA_BIN" ]; } || die "the console is not installed here ($JAR_RUN)"
    { : </dev/tty; } 2>/dev/null || die "--reset-owner asks questions: run it from a terminal"
    ACCOUNTS=$(accounts_file)
    signin_mode
    [ -n "$NEED_OWNER" ] || die "sign-in here is the tailnet: owners are the logins under monitor.auth.tailscale.users in $CONFIG"
    cat <<'RESET'

  tak3 console — reset an owner
  -----------------------------
  For an owner who cannot get in: a forgotten password, a lost phone and its
  recovery codes, or an account someone else took over. The account gets a
  new password and the owner role, and loses its two-step sign-in, which is
  set up again at the next sign-in. The console restarts, so every session
  ends, and every remembered device signs in again.

RESET
    OWNERS=$(run_setup owners --accounts "$ACCOUNTS" </dev/null | sed -n 's/^owner //p' | tr '\n' ' ' | sed 's/ $//' || true)
    if [ -n "$OWNERS" ]; then hint "owners now: $OWNERS"; else hint "no enabled owner now: the name you give becomes one"; fi
    [ -n "$who" ] || who=${OWNERS%% *}
    ask OWNER_ASK "owner to reset" "${who:-admin}"
    OWNER_ASK=$(printf '%s' "$OWNER_ASK" | tr 'A-Z' 'a-z' | tr -d ' ')
    for o in $OWNERS; do [ "$o" = "$OWNER_ASK" ] || others="$others $o"; done
    others=${others# }
    if [ -n "$others" ]; then
        hint "other owners: $others. If you do not know one of them, or think the console"
        hint "was taken over, disable them now; an owner can enable them again later."
        yesno dis "disable the other owners?" n
        if [ "$dis" = y ]; then extra+=(--disable-others); fi
    fi
    https=$(signin_url)
    hint "the new password is for the console's web page — not your server or sudo password"
    while :; do
        read_new_password
        stop_for_files
        out=$(printf '%s\n' "$OWNER_PW" | run_setup reset-owner --accounts "$ACCOUNTS" --username "$OWNER_ASK" "${extra[@]}") \
            && rc=0 || rc=$?
        why=$(cat "$SETUP_ERR")
        if [ "$rc" = 2 ]; then warn "${why:-refused}"; continue; fi
        break
    done
    systemctl start "$SERVICE" || warn "the console did not start — journalctl -u $SERVICE -n 30"
    if [ "$rc" != 0 ]; then OWNER_PW=""; rm -f "$SETUP_ERR"; die "the owner could not be reset: ${why:-exit $rc}"; fi
    name=$(printf '%s\n' "$out" | sed -n 's/^owner //p')
    ok "$name is an owner, with the new password and no two-step sign-in yet"
    printf '%s\n' "$out" | sed -n 's/^disabled //p' | while read -r d; do ok "disabled $d"; done
    ok "every session has ended, and every remembered device signs in again"
    show_generated "$name"
    OWNER_PW=""
    link=$(printf '%s\n' "$out" | sed -n 's/^link //p')
    echo
    if [ -n "$link" ] && [ -n "$https" ]; then
        echo " Sign in once with this link: it sets up two-step sign-in for $name, works"
        echo " once, and runs out in 24 hours:"
        echo
        echo "   $https$link"
    elif [ -n "$link" ]; then
        echo " This console has no HTTPS address and no tailnet yet, and takes passwords"
        echo " over nothing else — not plain http, not an SSH tunnel. Give it one (run"
        echo "  sudo $ME  with a domain that has a certificate here), then open, within"
        echo " 24 hours, its HTTPS address followed by:"
        echo
        echo "   $link"
    else
        echo " Sign in as $name — no setup link could be made: run this again to get one."
    fi
    [ -z "${why}" ] || hint "$why"
    rm -f "$SETUP_ERR"
}

[ "$(id -u)" -eq 0 ] || die "run with sudo"

if [ "${1:-}" = --reset-owner ]; then
    reset_owner "${2:-}"
    exit 0
fi

cat <<'BANNER'

  tak3 console - installer
  ------------------------
  Installs the console on this host: one page that watches every node.

  On a host in a tailnet it is published inside the tailnet only: it
  binds to this host's Tailscale address and `tailscale serve` fronts it
  with HTTPS, so nothing is exposed to the internet.

  Without a tailnet it listens on this machine only (127.0.0.1) and
  answers on an HTTPS port of its own, with the certificate your domain
  already has here. You choose the owner's username and password during
  this install, and two-step sign-in is required from the first sign-in.
  Without a tailnet it needs that certificate: passwords are taken over
  HTTPS or a tailnet only, never over plain http or an SSH tunnel.

  Step 5 asks the questions that make up its configuration file. Every
  question has a default and every one may be left blank: what you skip is
  written as a commented line you can fill in later. You review the whole
  file before it is written, and an existing configuration is never
  overwritten by a re-run.

  9 steps, a few minutes with the questions.

BANNER

# --- 1. locate the jar ------------------------------------------------------
if [ -n "$PACKAGED" ]; then
    say "The build" "installed by the package, with its own Java runtime"
    [ -f "$JAR" ] || die "$JAR is missing — reinstall the package: sudo apt install --reinstall tak3-console"
    ok "tak3-console $(dpkg-query -W -f='${Version}' tak3-console 2>/dev/null || echo '?')"
else
    say "Locating the jar" "the build being installed; it is copied into /var/lib/tak3-console and run through a stable symlink"
    JAR="${1:-}"
    if [ -z "$JAR" ]; then
        JAR=$(find_jar 'tak3-console-*.jar')
    fi
    [ -n "$JAR" ] && [ -f "$JAR" ] || die "jar not found — pass its path as the first argument"
    JAR_NAME=$(basename "$JAR")
    ok "$JAR"
fi

# --- 2. dependencies --------------------------------------------------------
if [ -n "$PACKAGED" ]; then
say "Java 21 and tools" "the runtime comes with the package; curl and jq from the distribution"
/opt/tak3-console/jre/bin/java -version 2>&1 | head -1 | sed 's/^/   /'
else
say "Java 21" "the runtime, installed from the distribution packages if it is missing"
if java -version 2>&1 | grep -q '"21'; then
    ok "already installed"
else
    # A single broken third-party mirror (Strato, Plesk, imunify360 ...) makes
    # apt-get update exit non-zero even when every index we need was fetched.
    # Warn and carry on — the install below is what actually has to succeed.
    apt-get update -qq || warn "apt-get update reported errors (broken mirror?) — continuing"
    apt-get install -y -qq openjdk-21-jdk || die "could not install openjdk-21-jdk
   If apt is blocked by an unrelated mirror, fix or disable that repo and re-run,
   or install Java 21 by hand, then re-run this script."
    java -version 2>&1 | head -1
fi
fi
command -v jq >/dev/null 2>&1 || apt-get install -y -qq jq || warn "jq not installed — the fleet check below will be skipped"
command -v curl >/dev/null 2>&1 || apt-get install -y -qq curl

# --- 3. Tailscale address ---------------------------------------------------
# Binding to the tailnet address (not 0.0.0.0) is what keeps this private while
# still letting the nodes on other servers POST their stream events here.
say "Where it listens" "this host's tailnet address when it has one; otherwise an address you choose"
TS_IP=""; TS_NAME=""; TS_LOGIN=""
if command -v tailscale >/dev/null 2>&1; then
    TS_IP=$(tailscale ip -4 2>/dev/null | head -1 || true)
    [ -n "$TS_IP" ] || warn "tailscale is installed but this host has no tailnet IP — 'sudo tailscale up' first to publish inside the tailnet"
fi
if [ -n "$TS_IP" ]; then
    if command -v jq >/dev/null 2>&1; then
        TS_NAME=$(tailscale status --json 2>/dev/null | jq -r '.Self.DNSName // ""' | sed 's/\.$//')
        # The person who owns this node in the tailnet — the natural first
        # owner of the console when sign-in goes through the tailnet.
        TS_LOGIN=$(tailscale status --json 2>/dev/null | jq -r '.User[(.Self.UserID|tostring)].LoginName // empty' 2>/dev/null || true)
    fi
    BIND=$TS_IP
    ok "tailnet address $TS_IP${TS_NAME:+  ($TS_NAME)}"
else
    hint "no tailnet here, so nothing publishes the console for you. Where should it listen?"
    hint "  127.0.0.1  this machine only — the right answer. People reach it on its own"
    hint "             HTTPS port, asked below"
    hint "  0.0.0.0    every interface, as plain http: a password typed there can be read"
    hint "             on the way. Only behind a firewall, and never without TLS in front"
    DEF_BIND=$(prev_arg server.address)
    ask BIND "listen address" "${DEF_BIND:-127.0.0.1}"
    case "$BIND" in
        127.*|::1|localhost) ;;
        *)
            warn "$BIND:$PORT answers plain http beyond this machine, where the console takes no"
            warn "password (monitor.auth.allow-plain-http lifts that, for a network you trust end"
            warn "to end). Nothing needs it: the HTTPS address asked below has a port of its own."
            # Kept without a fuss when a previous run chose it; asked when it is new.
            yesno KEEP_BIND "listen on $BIND anyway?" "$([ "$BIND" = "$DEF_BIND" ] && echo y || echo n)"
            if [ "$KEEP_BIND" != y ]; then
                BIND=127.0.0.1
                ok "this machine only, then"
            fi
            ;;
    esac
    ok "listening on $BIND:$PORT"
fi
# Where this script itself checks that the console answers.
CHECK_HOST=$BIND; [ "$BIND" = 0.0.0.0 ] && CHECK_HOST=127.0.0.1

# --- 4. user and directories ------------------------------------------------
say "Service user and directories" "an unprivileged user that owns its own directory and nothing else"
# A system account with no shell: it runs a service, nobody logs in as it.
id "$SERVICE_USER" >/dev/null 2>&1 || adduser --system --group --home "$INSTALL_DIR" --no-create-home \
    --shell /usr/sbin/nologin "$SERVICE_USER" >/dev/null
mkdir -p "$INSTALL_DIR"
# The service's from the start, so it can write its configuration there in a
# script install (see in_config_dir). Its parent is root's: the folder itself
# cannot be a link the service left.
chown "$SERVICE_USER:$SERVICE_USER" "$INSTALL_DIR"
if [ -n "$PACKAGED" ]; then
    install -d -m 750 -o root -g "$SERVICE_USER" /etc/tak3-console
    # A box moving from the script install keeps its configuration: it is
    # copied here once, and the old file stays where it was. Read as the
    # service user, whose folder that is (see as_service).
    if [ ! -f "$CONFIG" ] && [ -f "$INSTALL_DIR/application-local.yml" ]; then
        as_service cat -- "$INSTALL_DIR/application-local.yml" > "$CONFIG.new" \
            || { rm -f "$CONFIG.new"; die "could not read $INSTALL_DIR/application-local.yml as $SERVICE_USER"; }
        mv "$CONFIG.new" "$CONFIG"
        ok "taking the configuration of the script install ($INSTALL_DIR/application-local.yml)"
    fi
    ok "$INSTALL_DIR and /etc/tak3-console ready"
else
    # The unit runs a stable name; the versioned jar sits next to it. Updating
    # is then a symlink swap (update-console.sh), never an edit of the unit.
    if [ "$(readlink -f "$JAR")" != "$INSTALL_DIR/$JAR_NAME" ]; then
        place "$JAR" "$INSTALL_DIR/$JAR_NAME" "$SERVICE_USER" 0500
    fi
    ln -sfn "$INSTALL_DIR/$JAR_NAME" "$LINK"
    ok "$INSTALL_DIR ready ($LINK -> $JAR_NAME)"
fi

# --- 5. fleet configuration -------------------------------------------------
# Every value here may already exist in the arbiter's edge registry, or in a
# server list written for the import. Importing beats retyping API keys
# through a console.
#
#   arbiter yaml:  arbiter.edges[] -> name / api-url / api-key
#   server list:   servers[]       -> name / base-url / api-key
#
# Prints "name<TAB>url<TAB>key" per server found; silent when the file has none.
parse_registry() {
    awk '
        /^[[:space:]]*-[[:space:]]*name:[[:space:]]*/ {
            if (name != "" && url != "" && key != "") print name "\t" url "\t" key
            name = $0; sub(/^[^:]*:[[:space:]]*/, "", name); gsub(/[",]/, "", name)
            url = ""; key = ""; next
        }
        /^[[:space:]]*(base-url|api-url):[[:space:]]*/ {
            url = $0; sub(/^[^:]*:[[:space:]]*/, "", url); gsub(/[",]/, "", url); next
        }
        /^[[:space:]]*api-key:[[:space:]]*/ {
            key = $0; sub(/^[^:]*:[[:space:]]*/, "", key); gsub(/[",]/, "", key); next
        }
        END { if (name != "" && url != "" && key != "") print name "\t" url "\t" key }
    ' "$1" 2>/dev/null
}

# One node, as the yaml wants it. The registry that was imported already knows
# the name, url and key; these are the questions no file can answer.
ask_server_details() {
    local S_NAME=$1 S_URL=$2 S_KEY=$3 S_ROLE S_ARB S_MAX S_WATCH S_PUBLIC
    # A node that answers can be asked what it is, which turns three questions
    # into three confirmations.
    probe_node "$S_URL" "$S_KEY"
    choose S_ROLE "     role — origin ingests streams and holds DVR, edge serves viewers" \
        "origin edge" "$NODE_ROLE"
    yesno S_ARB "     does this one ALSO run the arbiter?" "$NODE_ARB"
    yesno S_WATCH "     monitoring only — never changed from this console?" n
    ask_opt S_PUBLIC "     viewer-facing URL, e.g. https://edge1.example.com" \
        "enables the TLS-expiry and synthetic-viewer checks for this node" "public-url for $S_NAME"
    ask S_MAX "     out capacity in Mbps" "1000"
    {
        echo "    - name: $S_NAME"
        echo "      base-url: $S_URL"
        echo "      api-key: $S_KEY"
        echo "      role: ${S_ROLE:-edge}"
        [ "$S_ARB" = y ] && echo "      arbiter: true"
        if [ "$S_WATCH" = y ]; then
            echo "      manage: false        # watched, never changed; give it the node's read-only key"
        fi
        if [ -n "$S_PUBLIC" ]; then
            echo "      public-url: $S_PUBLIC"
        else
            echo "      # public-url: https://<viewer-facing host>   # TLS expiry + playback checks"
        fi
        echo "      max-mbps: ${S_MAX:-1000}"
    } >> "$TMP_CONFIG"
    if [ "$S_WATCH" = y ]; then
        hint "use that node's READ-ONLY key above, so even a bug here cannot change it"
    fi
}

# Asks the node what it is, so the defaults are right more often than not.
# Never fatal: a console is often installed before the nodes it will watch.
NODE_ROLE=edge
NODE_ARB=n
probe_node() {
    local url=$1 key=$2 code body
    NODE_ROLE=edge; NODE_ARB=n
    code=$(curl -s -o /dev/null -w '%{http_code}' --max-time 4 "$url/actuator/health" 2>/dev/null || true)
    if [ "$code" != "200" ]; then
        warn "no answer from $url (HTTP ${code:-none}) — keeping it anyway; check the node, the port and the firewall later"
        return 0
    fi
    code=$(curl -s -o /dev/null -w '%{http_code}' --max-time 4 -H "X-Api-Key: $key" "$url/api/server-status" 2>/dev/null || true)
    case "$code" in
        200) ok "reached it, and the key works" ;;
        401|403) warn "that node answers but refused the API key (HTTP $code) — the console will show it as unreachable until the key matches"; return 0 ;;
        *)   warn "that node answers but /api/server-status said HTTP ${code:-none}"; return 0 ;;
    esac
    # DVR archives live on an origin; the arbiter says so itself.
    body=$(curl -sf --max-time 4 -H "X-Api-Key: $key" "$url/api/dvr" 2>/dev/null || true)
    case "$body" in *'"streamName"'*|*'"applicationName"'*) NODE_ROLE=origin;; esac
    body=$(curl -sf --max-time 4 -H "X-Api-Key: $key" "$url/api/arbiter/config" 2>/dev/null || true)
    case "$body" in *'"enabled":true'*) NODE_ARB=y;; esac
    [ "$NODE_ROLE" = origin ] && hint "it has DVR archives, so it looks like an origin"
    [ "$NODE_ARB" = y ] && hint "it is running an arbiter"
    return 0
}

# An existing config is the operator's, and this script does not rewrite it.
# "Existing" means finished, not non-empty: an empty fleet is a legitimate
# answer now (fill it in later), so the test is whether the file was written
# through to the end — a monitor: root and the push-key — rather than whether
# it happens to list a server. Only a genuinely half-written file, from a run
# interrupted at the prompts, is set aside and asked again.
CONFIGURED_SERVERS=0
CONFIG_COMPLETE=no
if [ -f "$CONFIG" ]; then
    CONFIGURED_SERVERS=$(grep -cE '^[[:space:]]+-[[:space:]]*name:' "$CONFIG" || true)
    if grep -q '^monitor:' "$CONFIG" && grep -q '^[[:space:]]*push-key:' "$CONFIG"; then
        CONFIG_COMPLETE=yes
    fi
fi

say "Console configuration" "the questions that make up application-local.yml; blank is a valid answer to every one"
if [ "$CONFIG_COMPLETE" = yes ]; then
    # Never overwritten and never merged into: the file holds every node's API
    # key and this script is run again for every re-install. The one exception
    # is a question a configuration from before sign-in cannot have answered,
    # and it is asked rather than assumed: left alone, such a console would
    # greet its operators with a password setup page they never chose.
    if ! grep -qE '^[[:space:]]+auth:' "$CONFIG"; then
        echo
        echo "   This configuration predates sign-in. How should people sign in?"
        pick_signin
        if [ "$SIGNIN" != password ]; then
            if [ -n "$TS_LOGIN" ]; then
                ask SSO_LOGIN "tailnet login of the first owner" "$TS_LOGIN"
            else
                ask_opt SSO_LOGIN "tailnet login of the first owner, e.g. you@example.com" \
                    "everyone else on the tailnet may look but not change" "the tailnet owner"
            fi
            BLOCK=$(mktemp)
            {
                echo "  # Sign-in is the tailnet: no login form, no passwords. tailscale serve"
                echo "  # names each person; everyone gets default-role, the users listed get"
                echo "  # their own. Added by install-console.sh; restart after editing."
                echo "  auth:"
                echo "    tailscale:"
                echo "      enabled: true"
                if [ "$SIGNIN" = both ]; then
                    echo "      # The sign-in page too, for accounts an owner makes under People."
                    echo "      passwords: true"
                fi
                echo "      default-role: viewer      # or none: only the users below may open it"
                if [ -n "$SSO_LOGIN" ]; then
                    echo "      users:"
                    echo "        - login: $SSO_LOGIN"
                    echo "          role: owner"
                else
                    echo "      users: []"
                    echo "      #  - login: you@example.com"
                    echo "      #    role: owner"
                fi
            } > "$BLOCK"
            in_config_dir cp -p -- "$CONFIG" "$CONFIG.before-sign-in.$(date +%s)"
            # Under the monitor: root, which is where the console reads it from.
            WITH_BLOCK=$(mktemp)
            in_config_dir cat -- "$CONFIG" | awk -v blockfile="$BLOCK" '
                { print }
                !done && /^monitor:[[:space:]]*$/ { while ((getline line < blockfile) > 0) print line; done = 1 }
            ' > "$WITH_BLOCK"
            write_config < "$WITH_BLOCK"
            rm -f "$BLOCK" "$WITH_BLOCK"
            ok "added tailnet sign-in to $CONFIG (the previous file is kept beside it)"
        else
            ok "password sign-in — the owner is asked for in step 6"
        fi
    else
        ok "keeping existing $CONFIG — nothing in it is changed"
    fi
    if [ "$CONFIGURED_SERVERS" -gt 0 ]; then
        ok "$CONFIGURED_SERVERS server(s) already configured"
    else
        warn "it lists no servers yet — add them under monitor.servers, then: systemctl restart $SERVICE"
    fi
    grep -q '^\s*manage-mode:' "$CONFIG" || warn "no manage-mode in $CONFIG — the management tabs stay off until you add one (coexist | full | read-only)"
    SSO_LOGIN=$(grep -oP '^\s*-\s*login:\s*\K\S+' "$CONFIG" | head -1 || true)
else
    if [ -f "$CONFIG" ]; then
        warn "$CONFIG looks half-written (no monitor: or no push-key — interrupted run?)"
        in_config_dir cp -- "$CONFIG" "$CONFIG.incomplete.$(date +%s)"
        warn "kept a copy beside it; asking again"
    fi
    echo "   This writes $CONFIG."
    echo "   Enter accepts the [default]; anything left blank is written as a"
    echo "   commented line you can fill in later. Nothing here is final."
    echo

    ask ENVIRONMENT "label for this console, shown beside the title" "production" \
        "production, staging, a customer name — blank hides it"
    echo

    echo "   How do people sign in?"
    pick_signin
    SSO_LOGIN=""
    if [ "$SIGNIN" != "password" ]; then
        if [ -n "$TS_LOGIN" ]; then
            ask SSO_LOGIN "tailnet login of the first owner" "$TS_LOGIN"
        else
            ask_opt SSO_LOGIN "tailnet login of the first owner, e.g. you@example.com" \
                "everyone else on the tailnet may look but not change" "the tailnet owner"
        fi
        [ -n "$SSO_LOGIN" ] || warn "no owner named — everyone on the tailnet will be a viewer until you add one under monitor.auth.tailscale.users"
    fi
    echo

    echo "   How may this console change the fleet?"
    echo "     coexist   - a cloud panel stays in charge of Nimble: transcoders and the arbiter are managed"
    echo "                 here, Nimble's own config (apps, routes, ports) stays read-only"
    echo "     full      - this console owns the fleet"
    echo "     read-only - see everything, change nothing"
    echo "     off       - monitoring only, no management tabs"
    choose MODE "manage mode" "coexist full read-only off" "coexist"
    echo

    # Look for a registry to import: IMPORT=... wins, else the usual locations.
    IMPORT_FILE="${IMPORT:-}"
    if [ -z "$IMPORT_FILE" ]; then
        for candidate in /var/lib/tak3-node/application-local.yml \
                         /var/lib/tak3-console/import.yml; do
            [ -f "$candidate" ] && [ -n "$(parse_registry "$candidate")" ] && { IMPORT_FILE="$candidate"; break; }
        done
    fi

    IMPORTED=""
    if [ -n "$IMPORT_FILE" ] && [ -f "$IMPORT_FILE" ]; then
        FOUND=$(parse_registry "$IMPORT_FILE")
        if [ -n "$FOUND" ]; then
            echo "   Found $(printf '%s\n' "$FOUND" | wc -l | tr -d ' ') server(s) in $IMPORT_FILE:"
            printf '%s\n' "$FOUND" | while IFS=$'\t' read -r n u _; do printf '     %-14s %s\n' "$n" "$u"; done
            yesno USE_IMPORT "Import them?" y
            [ "$USE_IMPORT" = n ] || IMPORTED="$FOUND"
        fi
    else
        echo "   No arbiter registry or server list found on this host to import from."
        echo "   Tip: scp one over and re-run with"
        echo "        sudo IMPORT=/root/application-local.yml $ME"
    fi
    echo
    # Build in a temp file and only publish it once the questions are answered,
    # so Ctrl-C at a prompt leaves no half-written config behind.
    TMP_CONFIG=$(mktemp)
    trap 'rm -f "$TMP_CONFIG"' EXIT
    {
        echo "# tak3 console — written by install-console.sh on $(date -u '+%Y-%m-%d %H:%M UTC')."
        echo "# Commented lines are the questions that were skipped: fill one in and"
        echo "# restart with   systemctl restart $SERVICE"
        echo "monitor:"
        echo "  environment: $ENVIRONMENT"
        echo "  # Each node pushes stream events with a key of its own, set when it is"
        echo "  # paired (Servers › the server › Keys for one added another way). This"
        echo "  # shared key is only for nodes set up that way before; empty is off."
        echo "  push-key: \"\""
        echo "  auth:"
        echo "    # Operator accounts (username, role, bcrypt hash). The console writes"
        echo "    # this file itself; nothing to fill in."
        echo "    accounts-file: $INSTALL_DIR/accounts.json"
        if [ "$SIGNIN" != "password" ]; then
            echo "    # Sign-in is the tailnet: no login form, no passwords. tailscale serve"
            echo "    # names each person; everyone gets default-role, the users listed"
            echo "    # get their own. Restart the service after editing."
            echo "    tailscale:"
            echo "      enabled: true"
            if [ "$SIGNIN" = "both" ]; then
                echo "      # The sign-in page too, for accounts an owner makes under People."
                echo "      passwords: true"
            fi
            echo "      default-role: viewer      # or none: only the users below may open it"
            if [ -n "$SSO_LOGIN" ]; then
                echo "      users:"
                echo "        - login: $SSO_LOGIN"
                echo "          role: owner"
            else
                echo "      users: []"
                echo "      #  - login: you@example.com"
                echo "      #    role: owner"
            fi
        fi
        echo "  # coexist | full | read-only | off — see application.yml for what each allows"
        echo "  manage-mode: $MODE"
        echo "  servers:"
    } > "$TMP_CONFIG"
    COUNT=0

    if [ -n "$IMPORTED" ]; then
        while IFS=$'\t' read -r S_NAME S_URL S_KEY; do
            [ -n "$S_NAME" ] || continue
            echo "   $S_NAME ($S_URL)"
            ask_server_details "$S_NAME" "$S_URL" "$S_KEY"
            COUNT=$((COUNT+1))
        done <<< "$IMPORTED"
        echo "   Imported $COUNT server(s). Add any that were missing below."
        echo
    fi

    echo "   The fleet: one entry per tak3 node (up to 8)."
    echo "   The API key is that node's full-control key — or its read-only key"
    echo "   for a box this console must only watch; install-node.sh prints both."
    echo "   Blank name finishes the list, and finishing with none is fine: the"
    echo "   console starts and the page shows what to add."
    echo
    while [ "$COUNT" -lt 8 ]; do
        ask S_NAME "node name (e.g. origin, blank to finish)"
        [ -n "$S_NAME" ] || break
        ask S_URL "  base-url" "http://127.0.0.1:8080" "where THIS host reaches that node — its tailnet IP, usually"
        ask S_KEY "  api-key"
        if [ -z "$S_KEY" ]; then
            warn "without a key the console cannot read that node — skipping $S_NAME"
            continue
        fi
        ask_server_details "$S_NAME" "$S_URL" "$S_KEY"
        COUNT=$((COUNT+1))
        echo
    done

    if [ "$COUNT" -eq 0 ]; then
        # Deliberately allowed: a console installed before its nodes still runs,
        # and its own page explains what is missing. The file explains it too.
        {
            echo "    # Nothing configured yet. One entry per node, then:"
            echo "    #   systemctl restart $SERVICE"
            echo "    # - name: origin"
            echo "    #   base-url: http://100.64.0.5:8080"
            echo "    #   api-key: <that node's full-control key, printed by install-node.sh>"
            echo "    #   role: origin          # origin ingests and records; edge serves viewers"
            echo "    #   arbiter: true         # only on the node that runs the arbiter"
            echo "    #   public-url: https://edge1.example.com   # TLS + playback checks"
            echo "    #   max-mbps: 1000"
            echo "    #   manage-mode: coexist  # this server only; blank inherits the fleet default"
        } >> "$TMP_CONFIG"
        skipped "the fleet itself — no servers yet"
        warn "no servers configured — the console will start and say so on its page"
    fi

    # ---- optional extras ---------------------------------------------------
    echo
    echo "   Optional. Enter skips each one; the yaml keeps a commented example."
    ask_opt PANEL_URL "cloud panel stats API base URL, e.g. https://<panel API host>" \
        "adds daily peak / unique viewers / view time from the panel that manages Nimble" "panel stats"
    PANEL_CLIENT=""; PANEL_KEY=""; PANEL_SLICE=""
    if [ -n "$PANEL_URL" ]; then
        ask PANEL_CLIENT "  panel API client id"
        ask PANEL_KEY "  panel API key"
        ask PANEL_SLICE "  panel data slice id"
    fi
    {
        if [ -n "$PANEL_URL" ] && [ -n "$PANEL_CLIENT" ] && [ -n "$PANEL_KEY" ] && [ -n "$PANEL_SLICE" ]; then
            echo "  panel-stats:"
            echo "    base-url: $PANEL_URL"
            echo "    client-id: $PANEL_CLIENT"
            echo "    api-key: $PANEL_KEY"
            echo "    data-slice: $PANEL_SLICE"
        else
            [ -n "$PANEL_URL" ] && warn "panel stats need all four values — left commented out"
            echo "  # Daily peak / unique viewers / view time from a cloud panel's API. All four."
            echo "  # panel-stats:"
            echo "  #   base-url: https://<panel API host>"
            echo "  #   client-id: <id>"
            echo "  #   api-key: <key>"
            echo "  #   data-slice: <slice id>"
        fi
        echo "  # Where the console saves what an operator edits in the browser"
        echo "  # (Security -> playback checks). It writes this itself."
        echo "  settings-file: $INSTALL_DIR/monitor-settings.json"
    } >> "$TMP_CONFIG"

    # ---- review ------------------------------------------------------------
    echo
    sub "Review"
    printf '   %-16s %s\n' "config" "$CONFIG"
    printf '   %-16s %s\n' "label" "$ENVIRONMENT"
    printf '   %-16s %s\n' "sign-in" "$SIGNIN${SSO_LOGIN:+  (owner: $SSO_LOGIN)}"
    printf '   %-16s %s\n' "manage-mode" "$MODE"
    printf '   %-16s %s\n' "servers" "$COUNT"
    grep -E '^    - name:' "$TMP_CONFIG" | sed 's/^    - name:/                    /' || true
    yesno WRITE "Write it?" y
    if [ "$WRITE" = n ]; then
        rm -f "$TMP_CONFIG"; trap - EXIT
        die "nothing was written — re-run when you are ready"
    fi
    write_config < "$TMP_CONFIG"
    rm -f "$TMP_CONFIG"
    trap - EXIT
    ok "$COUNT server(s) written to $CONFIG (manage-mode: $MODE)"
fi
chown -R "$SERVICE_USER:$SERVICE_USER" "$INSTALL_DIR"
if [ -n "$PACKAGED" ]; then
    chown root:"$SERVICE_USER" "$CONFIG"
    chmod 640 "$CONFIG"
else
    # chmod follows a link: done by the service user, whose files these are.
    as_service chmod 500 "$INSTALL_DIR/$JAR_NAME"
    as_service chmod 400 "$CONFIG"
fi

# --- 6. the owner, and where it answers --------------------------------------
# Made here, over this SSH session, before the service first starts: whoever
# runs this already proved who they are to the machine, so the console never
# runs a moment without an owner and there is nothing for anyone else to claim.
# The jar does the work (same hashing and rules as the web page), run as the
# service user so the files come out as the service writes them, detached
# from this terminal, with the password on a pipe — never in an argument or
# the environment, where other users of the machine could read it.
say "The owner, and where it answers" "the account that runs the console, made now so it never runs without one"
ACCOUNTS=$(accounts_file)
HAVE_TTY=""; { : </dev/tty; } 2>/dev/null && HAVE_TTY=yes
signin_mode

# HTTPS address: without a tailnet, the console answers on a port of its own
# with the certificate the domain already has here — nothing else in front.
DOMAIN=""; HTTPS_PORT=""; HTTPS_URL=""
if [ -z "$TS_IP" ]; then
    sub "HTTPS address"
    public_address
    if [ -n "$KEPT_ON" ] && [ -n "$KEPT_HOST" ] && [ -n "$KEPT_PORT" ]; then
        DOMAIN=$KEPT_HOST; HTTPS_PORT=$KEPT_PORT
        ok "kept: https://$DOMAIN:$HTTPS_PORT/ — change it under Settings › Public address"
    elif [ "${REVERSE_PROXY:-}" = yes ]; then
        ok "a reverse proxy on this machine serves it over HTTPS (REVERSE_PROXY=yes)"
        hint "it must send X-Forwarded-For and X-Forwarded-Proto: https — Caddy does by"
        hint "itself; nginx: proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;"
        hint "and proxy_set_header X-Forwarded-Proto \$scheme;"
    else
        # Without a tailnet this is the only way in: the console takes passwords
        # over HTTPS or a tailnet, never over plain http or an SSH tunnel.
        hint "Without a tailnet this is the console's only door: a name that points at this"
        hint "server and already has a certificate here (certbot's or the hosting panel's), e.g. console.example.com."
        while :; do
            ask DOMAIN "domain name (blank = stop here)" ""
            DOMAIN=$(printf '%s' "$DOMAIN" | tr 'A-Z' 'a-z' | sed 's#^https\?://##; s#[:/].*$##')
            [ -n "$DOMAIN" ] || die "no HTTPS address and no tailnet here, so nobody could sign in to the console:
   it takes passwords over HTTPS or a tailnet only, never over plain http or an SSH tunnel.
   Either get a certificate for a domain that points here (certbot, or your hosting panel),
   or put this machine on a tailnet (sudo tailscale up) — then run  sudo $ME  again.
   (A reverse proxy here that serves it over HTTPS:  sudo REVERSE_PROXY=yes $ME)"
            if ! printf '%s' "$DOMAIN" | grep -qE '^[a-z0-9.-]{1,253}$'; then
                warn "\"$DOMAIN\" is not a domain name"; continue
            fi
            # The console is not root and cannot read the domain's certificate;
            # a copy is made for it, and a daily job copies it again after renewal.
            if [ -n "$PACKAGED" ]; then CERT_CMD=(/usr/libexec/tak3-console/certificate "$DOMAIN")
            else CERT_CMD=(bash "$(dirname "$0")/certificate.sh" "$DOMAIN"); fi
            [ -n "$PACKAGED" ] || [ -f "$(dirname "$0")/certificate.sh" ] \
                || die "certificate.sh is not next to this script: copy tools/certificate.sh beside install-console.sh, then run this again"
            CERT_LOG=$(mktemp)
            if TAK3_FOR=console "${CERT_CMD[@]}" >"$CERT_LOG" 2>&1; then
                ok "certificate for $DOMAIN copied for the console"
                if grep -q 'daily job copies it again' "$CERT_LOG"; then
                    ok "a daily job copies it again after each renewal"
                else
                    warn "nothing copies it again after a renewal here (no daily job): after each one,"
                    warn "run  sudo $ME --certificate $DOMAIN  — the console picks the new copy up"
                fi
                grep -E 'trust store cannot follow|browsers may warn' "$CERT_LOG" | sed 's/^ *!! */   !!  /' || true
                rm -f "$CERT_LOG"
                break
            fi
            sed 's/^/      /' "$CERT_LOG"
            rm -f "$CERT_LOG"
            warn "no usable certificate for $DOMAIN on this server — another name, or blank to stop"
        done
        # Offered: a port nothing here listens on. (8443 is skipped where Plesk
        # is installed: its panel's port, even while the panel is stopped.)
        FREE_PORT=8443
        for p in 8443 9443 10443 18443 28443; do
            [ "$p" = 8443 ] && [ -d /usr/local/psa ] && continue
            [ "$p" = "$PORT" ] && continue
            ss -ltn "sport = :$p" 2>/dev/null | grep -q LISTEN || { FREE_PORT=$p; break; }
        done
        while :; do
            ask HTTPS_PORT "HTTPS port" "$FREE_PORT" "one nothing else here uses, from 1024 up; open it in the firewall"
            if ! printf '%s' "$HTTPS_PORT" | grep -qE '^[0-9]+$' || [ "$HTTPS_PORT" -lt 1024 ] || [ "$HTTPS_PORT" -gt 65535 ]; then
                warn "a number from 1024 to 65535"; continue
            fi
            [ "$HTTPS_PORT" != "$PORT" ] || { warn "$PORT is the console's own port — another one"; continue; }
            if ss -ltn "sport = :$HTTPS_PORT" 2>/dev/null | grep -q LISTEN; then
                warn "port $HTTPS_PORT is taken by $(ss -ltnp "sport = :$HTTPS_PORT" 2>/dev/null | awk 'NR==2 {print $NF}') — another one"; continue
            fi
            break
        done
        stop_for_files
        run_setup public-address --file "$PUBLIC_FILE" --host "$DOMAIN" --port "$HTTPS_PORT" --certificate "$DOMAIN" </dev/null >/dev/null \
            || die "could not save the HTTPS address: $(head -1 "$SETUP_ERR")"
        ok "https://$DOMAIN:$HTTPS_PORT/ saved — it opens while two-step sign-in is required of everyone"
    fi
    [ -n "$DOMAIN" ] && HTTPS_URL="https://$DOMAIN:$HTTPS_PORT"
fi

sub "Owner account"
OWNER_NAME=""; OWNER_LINK=""; OWNER_MADE=""; OWNERS=""
if [ -z "$NEED_OWNER" ]; then
    ok "sign-in is the tailnet${SSO_LOGIN:+, with $SSO_LOGIN as owner}: no password account is needed"
else
    OWNERS=$(run_setup owners --accounts "$ACCOUNTS" </dev/null | sed -n 's/^owner //p' | tr '\n' ' ' | sed 's/ $//' || true)
    if [ -n "$OWNERS" ]; then
        ok "owner account exists: $OWNERS — kept"
        # A new HTTPS address beside owners made before: it opens only while
        # two-step sign-in is required of everyone, which an owner may not have set.
        if [ -n "$HTTPS_URL" ] && [ "$(run_setup policy --accounts "$ACCOUNTS" </dev/null | sed -n 's/^policy //p' || true)" != everyone ]; then
            warn "two-step sign-in is not required of everyone, so $HTTPS_URL/ stays shut"
            hint "requiring it means everyone without it sets it up at their next sign-in,"
            hint "with a one-use setup link an owner makes under Settings › People"
            yesno REQUIRE_ALL "require two-step sign-in of everyone now?" y
            if [ "$REQUIRE_ALL" = y ]; then
                stop_for_files
                [ "$(run_setup policy --accounts "$ACCOUNTS" --two-step everyone </dev/null | sed -n 's/^policy //p' || true)" = everyone ] \
                    && ok "two-step sign-in is required of everyone" \
                    || warn "could not set it ($(head -1 "$SETUP_ERR")) — Settings › People › Two-step sign-in"
            else
                hint "Settings › People › Two-step sign-in: Everyone, when you are ready — the port opens then"
            fi
        fi
    elif [ -z "$HAVE_TTY" ]; then
        warn "no terminal to ask on: the owner is made on the next run of  sudo $ME  from a shell"
    else
        hint "The console's own account, for its web page. NOT your server or sudo"
        hint "password: a different one, kept in your password manager."
        while :; do
            ask OWNER_ASK "owner username" "admin" ""
            read_new_password
            # Two-step for everyone (which also opens the HTTPS address), and the
            # one-use link it is set up with: there is no setting it up without one.
            stop_for_files
            OWNER_OUT=$(printf '%s\n' "$OWNER_PW" | run_setup owner --accounts "$ACCOUNTS" --username "$OWNER_ASK" \
                --two-step everyone --link) && RC=0 || RC=$?
            WHY=$(cat "$SETUP_ERR")
            case "$RC" in
                0) break ;;
                2) warn "${WHY:-refused}" ;;
                3) OWNERS=$(printf '%s\n' "$WHY" | sed -n 's/^an owner exists already: //p' | head -1)
                   ok "an owner exists already: $OWNERS"; OWNER_PW=""; break ;;
                *) warn "the owner could not be made: ${WHY:-exit $RC}"
                   warn "the console starts without one: run  sudo $ME  again to make it"; OWNER_PW=""; break ;;
            esac
        done
        if [ -n "${OWNER_OUT:-}" ] && [ "${RC:-1}" = 0 ]; then
            OWNER_NAME=$(printf '%s\n' "$OWNER_OUT" | sed -n 's/^owner //p')
            OWNER_LINK=$(printf '%s\n' "$OWNER_OUT" | sed -n 's/^link //p')
            OWNER_MADE=yes
            ok "owner $OWNER_NAME made; two-step sign-in is required of everyone"
            if [ -z "$OWNER_LINK" ]; then
                warn "no first-sign-in link (${WHY:-?}): get one with  sudo $ME --reset-owner $OWNER_NAME"
            fi
            show_generated "$OWNER_NAME"
        fi
        OWNER_PW=""
    fi
fi

# --- the configuration's secrets, sealed --------------------------------------
# A node's api-key and the old shared push-key are written in the open by
# whoever adds them by hand; sealed here with the console's own key, which
# lives apart from the file, a copy of the configuration gives none of them away.
if [ -n "$PACKAGED" ]; then
    SEAL_KEY=/etc/tak3-console/secret.key
    SEAL_OUT=$("$JAVA_BIN" -jar "$JAR_RUN" setup seal-config --file "$CONFIG" --key-file "$SEAL_KEY" </dev/null 2>"$SETUP_ERR" || true)
else
    # Where the console looks for its key: /etc/tak3-console, else beside its accounts.
    SEAL_KEY=/etc/tak3-console/secret.key
    if ! as_service test -r "$SEAL_KEY"; then
        SEAL_KEY="$(dirname "$(accounts_file)")/secret.key"
        as_service test -f "$SEAL_KEY" || as_service sh -c 'umask 077; openssl rand -hex 32 > "$1"' sh "$SEAL_KEY"
    fi
    SEAL_OUT=$(run_setup seal-config --file "$CONFIG" --key-file "$SEAL_KEY" </dev/null || true)
fi
case "$SEAL_OUT" in
    "sealed 0") ok "no key in $CONFIG is written in the open" ;;
    sealed\ *) ok "sealed ${SEAL_OUT#sealed } key(s) in $CONFIG with $SEAL_KEY — back that key up apart from the file" ;;
    *) warn "could not seal the keys in $CONFIG: $(tail -1 "$SETUP_ERR" 2>/dev/null)" ;;
esac

# --- 7. systemd unit --------------------------------------------------------
say "Writing the systemd unit" "the service definition: bind address, port, config location"
# Another process on :$PORT would answer the health check below and make this
# script report success while the console is crash-looping on "port in use".
if ss -ltn "sport = :$PORT" 2>/dev/null | grep -q LISTEN; then
    if ! systemctl is-active --quiet "$SERVICE"; then
        OCCUPANT=$(ss -ltnp "sport = :$PORT" 2>/dev/null | awk 'NR==2 {print $NF}')
        die "port $PORT is already in use by $OCCUPANT
   Re-run on a free port:  sudo PORT=8095 $ME"
    fi
fi
ok "port $PORT is available"
if [ -n "$PACKAGED" ]; then
    # The package's unit reads where to listen from here; JAVA_OPTS is for the
    # JVM and is kept if it was set by hand.
    {
        echo "# tak3 console — written by tak3-console-setup. Re-run it to change these."
        echo "TAK3_CONSOLE_ARGS=\"--server.address=$BIND --server.port=$PORT\""
        grep '^JAVA_OPTS=' "$DEFAULTS" 2>/dev/null || echo '#JAVA_OPTS="-Xmx1g"'
    } > "$DEFAULTS.new"
    chmod 644 "$DEFAULTS.new"
    mv "$DEFAULTS.new" "$DEFAULTS"
    ok "wrote $DEFAULTS"
    if [ -f "$UNIT" ]; then
        # The script install's unit would override the package's.
        mv "$UNIT" "/root/$SERVICE.script-install.$(date +%s)"
        ok "moved from the script install: its unit is kept in /root"
    fi
else
[ -f "$UNIT" ] && cp "$UNIT" "/root/$SERVICE.bak.$(date +%s)"
cat > "$UNIT" <<EOF
[Unit]
Description=tak3 console
After=network.target tailscaled.service

[Service]
User=$SERVICE_USER
Group=$SERVICE_USER
ExecStart=/usr/bin/java -jar $LINK --spring.config.additional-location=$CONFIG --server.address=$BIND --server.port=$PORT
SuccessExitStatus=143
WorkingDirectory=$INSTALL_DIR
SyslogIdentifier=tak3-console
Restart=on-failure
RestartSec=5

[Install]
WantedBy=multi-user.target
EOF
fi

systemctl daemon-reload
systemctl enable --now "$SERVICE" >/dev/null 2>&1 || true
systemctl restart "$SERVICE"

# --- 8. verify --------------------------------------------------------------
say "Verifying" "proving the service runs, that it can write its own state, and which nodes it can reach"
for _ in $(seq 1 40); do
    curl -sf --max-time 3 "http://$CHECK_HOST:$PORT/actuator/health" >/dev/null 2>&1 && break
    sleep 1
done
systemctl is-active --quiet "$SERVICE" || die "service is not running — journalctl -u $SERVICE -n 30"
ok "service active and enabled at boot"

curl -sf --max-time 5 "http://$CHECK_HOST:$PORT/actuator/health" >/dev/null \
    && ok "health endpoint up" || die "health endpoint not responding — journalctl -u $SERVICE -n 30"

# The console reports per-server reachability on its health endpoint — the
# API itself needs a signed-in account now, and a script has none. Surface it
# here rather than leaving a half-configured fleet to be discovered in the browser.
sleep 4
HEALTH=$(curl -sf --max-time 8 "http://$CHECK_HOST:$PORT/actuator/health" || true)
NO_OWNER=""
BOTH_DOORS=""
grep -qE '^[[:space:]]+passwords:[[:space:]]*true' "$CONFIG" 2>/dev/null && BOTH_DOORS=yes
if [ -n "$HEALTH" ] && ! command -v jq >/dev/null 2>&1; then
    warn "jq missing — open the console to check which nodes are reachable"
elif [ -n "$HEALTH" ]; then
    # Tolerant of details it is not shown: a script must not stop on a
    # health answer that says less than it hoped.
    TOTAL=$(printf '%s' "$HEALTH" | jq '(.components.fleet.details.servers // []) | length' || echo 0)
    BAD=$(printf '%s' "$HEALTH" | jq -r '(.components.fleet.details.servers // [])[] | select(.reachable==false) | .name + " (" + (.error // "?") + ")"' || true)
    if [ "$TOTAL" -eq 0 ]; then
        warn "no servers in $CONFIG yet — the console runs and its page says what to add"
    elif [ -z "$BAD" ]; then
        ok "all $TOTAL configured node(s) reachable"
    else
        warn "unreachable nodes — check base-url / api-key / firewall:"
        printf '        %s\n' "$BAD"
    fi
    if [ "$(printf '%s' "$HEALTH" | jq -r '.components.fleet.details.accountsWritable')" != "true" ]; then
        warn "$SERVICE_USER cannot write the accounts file — no one will be able to sign in"
        printf '        fix: sudo chown %s %s\n' "$SERVICE_USER" "$INSTALL_DIR"
    fi
    if [ "$(printf '%s' "$HEALTH" | jq -r '.components.fleet.details.setupRequired')" = "true" ]; then
        # Nothing on the web makes one: only this script, from a shell.
        NO_OWNER=yes
        warn "no owner account yet — run  sudo $ME  again from a shell, which asks for one"
    else
        ok "owner account exists"
    fi
else
    warn "the health endpoint did not answer yet — check journalctl -u $SERVICE"
fi

# The HTTPS address, checked the way a visitor meets it: the port open, the
# certificate valid for the name, the name pointing here, the firewall open.
HTTPS_OK=""
if [ -n "$HTTPS_URL" ]; then
    sub "HTTPS address: $HTTPS_URL/"
    for _ in $(seq 1 20); do
        ss -ltn "sport = :$HTTPS_PORT" 2>/dev/null | grep -q LISTEN && break
        sleep 1
    done
    if ! ss -ltn "sport = :$HTTPS_PORT" 2>/dev/null | grep -q LISTEN; then
        warn "port $HTTPS_PORT is not open — Settings › Public address says why;"
        warn "or: journalctl -u $SERVICE | grep -i 'public address'"
    else
        ok "port $HTTPS_PORT is open on every address"
        # Asked here, by name, so the certificate is checked against it as a browser would.
        TLS_ERR=$(mktemp)
        TLS_CODE=$(curl -sS -o /dev/null -w '%{http_code}' --max-time 8 --resolve "$DOMAIN:$HTTPS_PORT:127.0.0.1" \
            "https://$DOMAIN:$HTTPS_PORT/login" 2>"$TLS_ERR" || true)
        case "$TLS_CODE" in
            200) ok "answers with a valid certificate for $DOMAIN"; HTTPS_OK=yes ;;
            000) warn "TLS failed: $(head -1 "$TLS_ERR")" ;;
            *)   warn "answered HTTP $TLS_CODE" ;;
        esac
        rm -f "$TLS_ERR"
    fi
    # Does the name lead here? Behind NAT the public address is not on any
    # interface, so a mismatch is said, not failed on.
    NAME_ADDRS=$(getent ahosts "$DOMAIN" 2>/dev/null | awk '{print $1}' | sort -u | tr '\n' ' ' | sed 's/ $//' || true)
    OWN_ADDRS=" $(hostname -I 2>/dev/null || true) "
    if [ -z "$NAME_ADDRS" ]; then
        warn "$DOMAIN does not resolve yet — point its DNS record at this server"
    else
        HERE=""
        for a in $NAME_ADDRS; do case "$OWN_ADDRS" in *" $a "*) HERE=yes ;; esac; done
        if [ -n "$HERE" ]; then ok "$DOMAIN points at this server ($NAME_ADDRS)"
        else hint "$DOMAIN points at $NAME_ADDRS; this server's own addresses are$(printf '%s' "$OWN_ADDRS" | sed 's/ *$//'). Behind NAT that is right."; fi
    fi
    # The firewall on this server; the one at the hosting provider is out of sight from here.
    if command -v ufw >/dev/null 2>&1 && ufw status 2>/dev/null | grep -q '^Status: active'; then
        if ufw status 2>/dev/null | grep -qE "^$HTTPS_PORT(/tcp)?[[:space:]]+ALLOW"; then
            ok "ufw allows $HTTPS_PORT/tcp"
        else
            warn "ufw is on and does not allow $HTTPS_PORT/tcp"
            yesno OPEN_UFW "allow $HTTPS_PORT/tcp in ufw now?" y
            if [ "$OPEN_UFW" = y ]; then ufw allow "$HTTPS_PORT/tcp" >/dev/null && ok "ufw allows $HTTPS_PORT/tcp"; fi
        fi
    fi
    hint "a firewall your provider runs in front of this server (a cloud panel or security group) is"
    hint "invisible from here: if $HTTPS_URL/ does not open from your computer, open"
    hint "$HTTPS_PORT/tcp there. Settings › Public address then checks from your browser too."
fi

# --- 9. publish inside the tailnet, or say where it answers ----------------
# Where a node on this same machine reaches the console: as it listens, from here.
LOCAL_HOST=$CHECK_HOST
case "$LOCAL_HOST" in *:*) LOCAL_HOST="[$LOCAL_HOST]" ;; esac
if [ -z "$TS_IP" ]; then
say "Where it answers" "no tailnet on this host: its HTTPS address, and nothing else"
if [ -n "$HTTPS_URL" ]; then
    if [ -n "$HTTPS_OK" ]; then ok "$HTTPS_URL/ — the console's own HTTPS port, two-step sign-in for everyone"
    else warn "$HTTPS_URL/ is set but did not check out above — fix that first: it is the only way in"; fi
else
    ok "through your reverse proxy's HTTPS address (REVERSE_PROXY=yes)"
fi
hint "plain http and SSH tunnels take no password: people sign in at the HTTPS address"
else
say "Publishing to the tailnet" "pointing tailscale serve at the console so it answers on https://<host>.<tailnet>.ts.net"
# Match the exact target, not just the port: an earlier install may have left a
# proxy pointing at 127.0.0.1, which answers every request with a 502.
if tailscale serve status 2>/dev/null | grep -q "$TS_IP:$PORT"; then
    ok "tailscale serve already points at $TS_IP:$PORT"
else
    if tailscale serve status 2>/dev/null | grep -q ":$PORT"; then
        warn "replacing a serve config that points somewhere else"
        tailscale serve --https=443 off >/dev/null 2>&1 || true
    fi
    # Proxy to the address the service actually binds to. Pointing serve at
    # 127.0.0.1 yields a 502: nothing listens there, the app is on $TS_IP.
    tailscale serve --bg "http://$TS_IP:$PORT" 2>/dev/null \
        || tailscale serve https / "http://$TS_IP:$PORT" 2>/dev/null \
        || warn "could not configure tailscale serve automatically — run it manually:
        sudo tailscale serve --bg http://$TS_IP:$PORT"
fi
# Prove the proxy reaches the app rather than trusting the config.
if [ -n "$TS_NAME" ]; then
    SERVE_CODE=$(curl -s -o /dev/null -w '%{http_code}' --max-time 8 "https://$TS_NAME/" || true)
    case "$SERVE_CODE" in
        200) ok "https://$TS_NAME/ serves the console" ;;
        502|000) warn "https://$TS_NAME/ answered $SERVE_CODE — the proxy is not reaching $TS_IP:$PORT" ;;
        *)   warn "https://$TS_NAME/ answered HTTP $SERVE_CODE" ;;
    esac
fi
tailscale serve status 2>/dev/null | sed 's/^/   /' || true
fi
if [ -n "$PACKAGED" ]; then
    UPDATE="sudo apt update && sudo apt install tak3-console"
    REMOVE="sudo apt remove tak3-console"
else
    UPDATE="sudo bash update-console.sh <new jar>"
    REMOVE="sudo bash uninstall-console.sh"
fi
# Where people sign in: the tailnet name, the console's HTTPS address, or the proxy's.
if [ -n "$TS_IP" ]; then SIGNIN_AT="https://${TS_NAME:-<this-host>.<tailnet>.ts.net}"
elif [ -n "$HTTPS_URL" ]; then SIGNIN_AT="$HTTPS_URL"
else SIGNIN_AT="https://<your proxy's address>"; fi
OPEN="$SIGNIN_AT/"
HOWTO=""
if [ -n "$OWNER_LINK" ]; then
    HOWTO="
 FIRST SIGN-IN — once, from your own computer${TS_IP:+, on the tailnet}:

   1. Open this link. It sets up two-step sign-in for $OWNER_NAME, works
      once, and runs out in 24 hours:

        $SIGNIN_AT$OWNER_LINK

   2. Sign in as $OWNER_NAME with the password you just chose, scan the QR
      code with an authenticator app (Google Authenticator, Bitwarden,
      Microsoft Authenticator, 1Password), type the code it shows, and save
      the recovery codes.

   3. From then on:  $OPEN  — username, password, code.
      Add people under Settings › People; each sets up two-step sign-in
      with a one-use link you make for them there.
"
elif [ -n "$OWNERS" ]; then
    HOWTO="
 OPEN IT:  $OPEN  — sign in with the owner account ($OWNERS).
"
elif [ -n "$NO_OWNER" ] || { [ -n "$NEED_OWNER" ] && [ -z "$OWNER_MADE" ]; }; then
    HOWTO="
 NO OWNER YET: run  sudo $ME  again from a shell. It asks for
 one and prints the link for the first sign-in; nothing on the console's
 page makes one.
"
fi
[ -z "$NEED_OWNER" ] || HOWTO="$HOWTO
 An owner locked out later:  sudo $ME --reset-owner
"

# Linking the streaming servers, once someone can sign in: the owner makes a
# one-use code in the console, and each server's setup sends it with its key.
PAIRING=""
if [ -z "$TS_IP" ]; then
    PAIRING="
 LINKING STREAMING SERVERS — after your first sign-in, for each server:

   1. In the console: Servers › Add server › Make a code. The page shows a
      command with a one-use code in it (15 minutes, works once).
   2. On that server, give its node a certificate and a free HTTPS port,
      one nothing else there uses (from 1024 up, open in its firewall). The
      first command names a free one. Then pair:

        sudo tak3-node-setup --certificate node.example.com
        sudo tak3-node-setup --https-port <that port> --pair $SIGNIN_AT/pair/<code>

      Paste the --pair address exactly as the page shows it. The node sends
      the code and its key to the console over HTTPS, and the console calls
      it back over HTTPS before it trusts it.
"
fi

# Whether a node elsewhere can reach the console to push its events.
if [ -n "$TS_IP" ]; then
    PUSH_REACH="The streaming servers reach it over the tailnet."
else
    case "$CHECK_HOST" in
        127.*|::1) PUSH_REACH="A node elsewhere pushes to an address of the console it can reach${HTTPS_URL:+ — $HTTPS_URL}." ;;
        *) PUSH_REACH="The streaming servers must reach $LOCAL_HOST:$PORT: firewall that port to them." ;;
    esac
fi

# --- what to do next --------------------------------------------------------
cat <<EOF

────────────────────────────────────────────────────────────
 tak3 console installed.

   open           : $OPEN
   config         : $CONFIG
   accounts       : $INSTALL_DIR/accounts.json  (written by the console)
   logs           : journalctl -u $SERVICE -f
   update         : $UPDATE
   remove         : $REMOVE

${SKIPPED:+
 Left blank, written as commented lines in the config:$SKIPPED

 Fill any of them in, then:  sudo systemctl restart $SERVICE
}
${HOWTO}${PAIRING}${SSO_LOGIN:+
 Sign-in is the tailnet: open the address above from a device signed in
 as a person and you are in — $SSO_LOGIN as owner, everyone else on the
 tailnet as viewer. Give people more under monitor.auth.tailscale.users
 in $CONFIG and restart the service.
}${BOTH_DOORS:+
 The sign-in page is open too, for people outside the tailnet: as an owner
 on the tailnet, add their accounts under Settings › People, and require
 two-step sign-in there. Put HTTPS in front before exposing it to the
 internet (tailscale serve only covers the tailnet).
}
 Instant stream up/down instead of polling: a server paired from
 Servers › Add server is told where to push, with a key of its own. For one
 in the configuration file or added by hand: Servers › the server › Keys ›
 Give it its own key. ${PUSH_REACH}
────────────────────────────────────────────────────────────
EOF
