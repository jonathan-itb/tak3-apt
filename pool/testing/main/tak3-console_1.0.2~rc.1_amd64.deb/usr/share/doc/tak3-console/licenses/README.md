# licenses/

Full text of every licence referenced by the root `NOTICE` file.

| File | Licence |
| --- | --- |
| `Apache-2.0.txt` | Apache License 2.0 |
| `MIT.txt` | MIT License |
| `BSD-3-Clause.txt` | BSD 3-Clause "New" or "Revised" License |
| `BSD-2-Clause.txt` | BSD 2-Clause "Simplified" License |
| `EPL-2.0.txt` | Eclipse Public License 2.0 |
| `CC0-1.0.txt` | Creative Commons Zero v1.0 Universal |
| `EPL-1.0.txt` | Eclipse Public License 1.0 — reference only, not currently referenced |

All texts are the canonical SPDX texts, taken from
<https://github.com/spdx/license-list-data> (`json/details/<id>.json`,
field `licenseText`).

## Regenerating the NOTICE when dependencies change

Run this from the repository root whenever a dependency is added, removed
or upgraded in `tak3-node` or `tak3-console`:

```sh
export JAVA_HOME="$(dirname "$(dirname "$(readlink -f "$(command -v java)")")")"

for m in tak3-node tak3-console; do
  ./mvnw -B -pl "$m" dependency:list \
    -DincludeScope=runtime \
    -DoutputFile="/tmp/deps-$m.txt"
done

# Merged, de-duplicated list of every COMPILE + RUNTIME artifact:
cat /tmp/deps-*.txt \
  | grep -E ':(compile|runtime)' \
  | sed 's/^ *//; s/ -- .*//' \
  | sort -u
```

`-DincludeScope=runtime` yields compile + runtime and excludes `test` and
`provided`, which is exactly the set that is redistributed.

Then diff that list against the tables in the root `NOTICE` and update
any added, removed or version-bumped entry, and the `Totals:` count.

CI does that diff on every build and fails until `NOTICE` matches; run it
locally the same way:

```sh
./mvnw -B org.codehaus.mojo:license-maven-plugin:2.4.0:aggregate-add-third-party \
  -Dlicense.excludedScopes=test,provided -Dlicense.outputDirectory=target/license
python3 tools/check-notice.py NOTICE target/license/THIRD-PARTY.txt
```

It names every artifact that is missing, stale, no longer shipped, or listed
under a licence it is not offered under. The `Product version:` line is
filled in by `packaging/build.sh` in the copy each package carries.

### Finding the licence of a new artifact

Read the declared `<licenses>` block from the artifact's POM in the local
repository (falling back to its parent POM, which is where Spring, logback
and others declare theirs):

```sh
grep -A6 '<licenses>' ~/.m2/repository/<group/path>/<artifact>/<version>/<artifact>-<version>.pom
```

Do **not** assume a licence from memory — several artifacts here changed
licence across versions. logback is the live example: releases before
1.3.x were EPL-1.0 or LGPL-2.1, while 1.5.34 declares **EPL-2.0** or
LGPL-2.1-only. Always re-read the POM of the exact version shipped.

If a new artifact introduces a licence not already in this directory, add
its canonical SPDX text here as `<SPDX-ID>.txt` and add a matching section
to the `NOTICE`.

## Things that are not Maven dependencies

The `NOTICE` also covers browser libraries vendored under
`tak3-console/src/main/resources/static/vendor/`. These are not visible to
Maven, so they must be maintained by hand. Current contents:

| File | Component | Version | Licence |
| --- | --- | --- | --- |
| `hls.min.js` | hls.js | 1.5.20 | Apache-2.0 |
| `dash.all.min.js` | dash.js | 4.7.4 | BSD-3-Clause |
| `dash.all.min.js.LICENSE.txt` | dash.js embedded-deps attribution | 4.7.4 | (attribution file) |
| `nimio-v1.14.0.js`, `.css`, `assets/*.js` | Nimio (SLDP player, Softvelum) | v1.14.0 | MIT |
| `nimio-v1.14.0.LICENSE.txt` | Nimio licence text as shipped | v1.14.0 | (licence file) |

When a vendored bundle is replaced, re-derive its version from the file
itself and refresh the matching attribution. For dash.js:

```sh
grep -o -E 'return"[0-9]+\.[0-9]+\.[0-9]+"' \
  tak3-console/src/main/resources/static/vendor/dash.all.min.js

curl -sSL -o tak3-console/src/main/resources/static/vendor/dash.all.min.js.LICENSE.txt \
  "https://cdn.dashjs.org/v<VERSION>/dash.all.min.js.LICENSE.txt"
```

For hls.js the version is the sole `"x.y.z"` string literal in `hls.min.js`.
Nimio carries its version in its own file names, and `Nimio.version()` reports
it in the browser; upgrade it by unpacking a newer `dist.tar.gz` from
https://github.com/Softvelum/nimio/releases into `vendor/`, keeping the
`assets/` folder beside the script, and updating the tags in `index.html`.
